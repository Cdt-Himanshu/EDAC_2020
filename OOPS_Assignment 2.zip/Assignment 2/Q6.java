import java.util.*;
class Q6
{
	public static void main (String args[])
	{
	int sum=0;
	Scanner s=new Scanner(System.in);
	int arr[]=new int[10];
	System.out.println("Enter values of 10 elements : ");
		for (int i=0;i<10;i++)
		{
		arr[i]=s.nextInt();
		sum=sum+arr[i];
		}
		double avg=(double)sum/10;
		System.out.println("Sum of 10 Subjects = " +sum);
		System.out.print("Average of 10 Subjects = " +avg);
	}
}