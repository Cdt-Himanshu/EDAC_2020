import java.util.*;
class Q9
{
	public static void main (String args[])
	{
	int n, i, flag=0;
	Scanner s=new Scanner (System.in);
	System.out.print ("Enter Size of an array : ");
	n=s.nextInt();
	int a[]=new int[n];
		for (i=0; i<n; i++)
		{
			a[i]=s.nextInt();
		}
	System.out.print ("Enter Searching Element : ");
	int x=s.nextInt();
		for (i=0; i<n; i++)
		{
			if (a[i]==x)
			{
				flag=1;
			break;
			}
			else
				flag=0;
		}
	if (flag==1)
		System.out.print ("Element is found at " +(i+1) +" location");
	else
		System.out.print ("Element NOT found");
	}
}