import java.util.*;
class Q5
{
	public static void main (String args[])
	{
		int i;
		Scanner sc=new Scanner(System.in);
		System.out.print ("Enter lower limit : ");
		int m=sc.nextInt();
		System.out.print ("Enter upper limit : ");
		int u=sc.nextInt();
		for (int x=m;x<=u;x++)
		{
			for (i=2;i<x;i++)
			{
				if (x%i==0)
				break;
			}
		if (i==x)
		System.out.println(x);
		}
	}
}