class Q8
{
	public static void main(String args[])
	{
	int arr[]=new int[]{7,8,9,4,5,1,6,2,3,0};
	System.out.print("Original Array : ");
		for (int i=0; i<arr.length; i++)
		{
		System.out.print (arr[i] +" ");
		}
		System.out.println();
	System.out.print("Reversed Array : ");
	for (int i=arr.length-1; i>=0; i--)
		{
		System.out.print (arr[i] +" ");
		}
	}
}