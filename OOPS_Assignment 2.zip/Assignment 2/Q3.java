import java.util.*;
class Q3
{
	public static void main (String args[])
	{
	int count=0;
	Scanner s=new Scanner(System.in);
	System.out.print("Enter number : ");
	int num=s.nextInt();
	for(int i=1;i<=num;i++)
	{
		if (num%i==0)
		count++;
	}
	if (count==2)
		System.out.println("Prime Number");
	else
		System.out.println("Not Prime Number");
	}
}