import java.util.*;
class Q7
{
	public static void main (String args[])
	{
	int n, temp=0;
		Scanner s=new Scanner(System.in);
		System.out.print ("Enter size of array : ");
		n=s.nextInt();
		int arr[]=new int [n];
		System.out.println ("Enter Elements of Array: ");
		for (int i=0; i<arr.length;i++)
		{
		arr[i]=s.nextInt();
		}
			for (int i=0;i<arr.length;i++)
			{
				for (int j=i+1;j<arr.length;j++)
				{
					if (arr[i]<arr[j])
					{
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
					}
				}
			}
		System.out.println();	
		for (int i=0;i<arr.length;i++)
		{
		System.out.print (arr[i] +" ");
		}
	}
}