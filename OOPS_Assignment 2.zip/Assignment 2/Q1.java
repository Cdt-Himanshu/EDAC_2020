import java.util.*;
class Q1
{
	public static void main (String args[])
	{
		int n, num;
		Scanner s=new Scanner(System.in);
		System.out.print("Enter the number : ");
		num=s.nextInt();
		System.out.print("Range upto which table is to be printed : ");
		n=s.nextInt();
		for (int i=1; i<=n; i++)
		{
			System.out.println(num +" x " +i +" = " +(num*i));
		}
	}
}