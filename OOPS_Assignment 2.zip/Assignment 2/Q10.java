import java.util.*;
class Q10
{
	public static void main(String args[])
	{
		int sumE=0, sumO=0;
		Scanner s = new Scanner(System.in);
		System.out.print("Enter size of array : ");
		int n = s.nextInt();
		int a[]= new int[n];
		System.out.println("Enter elements of array : ");
		for (int i=0; i<a.length; i++)
		{
			a[i]=s.nextInt();
		}
		for (int i=0; i<a.length; i++)
		{
			if (a[i] % 2 ==0)
			sumE= sumE+a[i];
			else
			sumO=sumO+a[i];
		}
	System.out.println("Sum of Even Elements in the array : " +sumE);	
	System.out.println("Sum of Odd Elements in the array : " +sumO);
	}
}