import java.util.*;
class Q2
{
	public static void main(String args[])
	{
		int rev=0;
		Scanner s=new Scanner(System.in);
		System.out.print("Enter number : ");
		int num=s.nextInt();
		for (; num!=0; num/=10)
		{
			int digit=num%10;
			rev=rev*10+digit;
		}
		System.out.println("Reversed number : "+rev);
	}
}