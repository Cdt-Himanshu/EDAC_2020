import java.util.*;
class Q13
{
	public static void main(String args[])
	{
	Scanner sc = new Scanner (System.in);
	System.out.println("Enter value of 3 numbers");
	int x=sc.nextInt();
	//System.out.println("x = " +x);
	int y=sc.nextInt();
	//System.out.println("y = " +y);
	int z=sc.nextInt();
	System.out.println("x = " +x);
	System.out.println("y = " +y);
	System.out.println("z = " +z);
		if (x>y && x>y)
		{
		System.out.println("x is Greatest");
		}
			else if (y>z)
			{
			System.out.println("y is Greatest");
			}
				else
				{
				System.out.println("z is Greatest");
				}
}
}