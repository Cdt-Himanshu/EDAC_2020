class Q5
{
	public static void main (String args[])
	{
	String s1=args[0];
	System.out.println("Welcome " +s1);
	}
}