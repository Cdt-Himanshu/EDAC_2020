import java.util.*;
class Q13B
{
	public static void main(String args[])
	{
	Scanner s=new Scanner(System.in);
	System.out.print("Enter first number : ");
	int num1=s.nextInt();
	System.out.print("Enter second number : ");
	int num2=s.nextInt();
	System.out.print("Enter third number : ");
	int num3=s.nextInt();
	int temp=(num1>num2)?num1:num2;
	int result=(num3>temp)?num3:temp;
	System.out.print("Greatest number : " +result);
	}
}