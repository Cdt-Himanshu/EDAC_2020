public class Q3
{
	private static int x = 3, y=2;
	public static void main(String args[])
	{
		System.out.println("Initial Values\nx = " +x +"\ny = "+y);
		System.out.println("A. y = " +(Math.pow(x,2) + (3*x) - 7));
		System.out.println("B. y = " +(x++ + ++x) +" x = "+x);
		System.out.println("C. z = " +(x++ - --y - --x + x++) +" y = "+y + " x = "+x);
		boolean x = false, y=true;
		System.out.println("\nInitial Values\nx= "+x +" y = "+y);
		System.out.println("D. z = " +(x && y || !(x||y)));
	}
}