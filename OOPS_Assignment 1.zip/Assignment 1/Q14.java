import java.util.*;
class Q14
{
	public static void main (String args[])
	{
	System.out.print("Enter year : ");
	Scanner sc=new Scanner (System.in);
	int leap=sc.nextInt();
		if ((leap%4==0 && leap%100!=0) || (leap%400==0))
		{
		System.out.println(leap +" is a leap year");
		}
		else
		{
		System.out.println(leap +" is NOT a leap year");
		}
}
}