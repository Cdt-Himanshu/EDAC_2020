import java.util.*;
class Q12
{
	public static void main (String args[])
	{
		float da, hra,gs;
		float bs;
		Scanner s=new Scanner(System.in);
		System.out.print("Enter Basic Salary = ");
		bs=s.nextFloat();
			if (bs < 10000)
			{
			hra=bs*10/100;
			da=bs*90/100;
			}
			else
			{
			hra=2000;
			da=bs*98/100;
			}
		gs=bs+da+hra;
		System.out.println("Gross Salary = "+gs);	
	}
}