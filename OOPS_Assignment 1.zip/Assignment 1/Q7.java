import java.util.*;
class Q7
{
	public static void main(String args[])
	{
		float total=0;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter Marks obtained in 5 Subjects : ");
			for (int i=1;i<=5;i++)
			{
			double sub=sc.nextDouble();
			total+=sub;
			}
		double percentage=total/500*100;
		System.out.println("Total Marks secured in 5 Subjects = "+total);
		System.out.println("Percentage Marks = "+percentage +"%");
	}
}