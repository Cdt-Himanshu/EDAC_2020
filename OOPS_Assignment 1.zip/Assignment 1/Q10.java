import java.util.*;
class Q10
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter temperatue in Fahrenheit : ");
		double f=sc.nextDouble();
		double c=5*(f-32)/9;
		System.out.print("Temperature in Celsius : "+c);
	}
}