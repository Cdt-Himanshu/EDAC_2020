import java.util.*;
class Q11
{
	public static void main (String args[])
	{
	Scanner sc=new Scanner (System.in);
	System.out.println("Enter values of x & y");
	int x=sc.nextInt();
	int y=sc.nextInt();
	System.out.println("Value of x before swap=" +x);
	System.out.println("Value of y before swap=" +y);
	x=x-y;
	y=x+y;
	x=y-x;
	System.out.println("Value of x after swap=" +x);
	System.out.println("Value of y after swap=" +y);	
}
}