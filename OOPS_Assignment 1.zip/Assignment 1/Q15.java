import java.util.*;
class Q15
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Martial Status : ");
		char martialStatus=sc.next().charAt(0);
		System.out.println("Enter your Gender : ");
		char gender=sc.next().charAt(0);
		System.out.println("Enter your Age : ");
		int age=sc.nextInt();
		if (martialStatus=='m' || martialStatus=='M')
		{
		System.out.println("You cannot marry");
		}
		else if (martialStatus =='u' || martialStatus =='U')
		{
			if(gender =='m'|| gender =='M')
			{
				if(age>=21)
				System.out.println("You are eligible for marriage");
				else
				System.out.println("You cannot marry");
			}
			else if(gender =='f'|| gender =='F')
			{
				if(age>=18)
				System.out.println("You are eligible for marriage");
				else
				System.out.println("You cannot marry");
			}
			else
			{
				System.out.println("Invalid Gender Input");
			}
		}
		else
		System.out.println("Invalid Martial Status Input");
	}
}