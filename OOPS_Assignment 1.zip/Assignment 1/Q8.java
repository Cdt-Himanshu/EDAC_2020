import java.util.*;
class Q8
{
	public static void main(String args[])
	{
	Scanner sc=new Scanner (System.in);
	int p=sc.nextInt();
	int r=sc.nextInt();
	int t=sc.nextInt();
	int i=p*r*t;
	System.out.println("Principle Amount = " +p);
	System.out.println("Rate of Interest = " +r);
	System.out.println("Time = " +t);
	System.out.println("Simple Interest = " +i);
}
}