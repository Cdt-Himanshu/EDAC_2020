import java.util.*;
class Q9
{
	public static void main(String args[])
	{
		int m, day, month, year;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter number of days : ");
		m = sc.nextInt();
		year=m/365;
		m=m%365;
		System.out.println(year +" years");
		month=m/30;
		m=m%30;
		System.out.println(month +" months");
		day=m;
		System.out.println(day +" days");	
	}
}